import { Router, Response } from 'express';
import { MedicalRecordModel } from '../models/MedicalRecord';
import { AuthRequest, authenticate, authorize } from '../middleware/auth';
import { NotificationModel } from '../models/Notification';
import { supabaseAdmin } from '../config/supabase';

const router = Router();

// Upload medical record (Patient)
router.post('/', authenticate, authorize(['patient']), async (req: AuthRequest, res: Response) => {
  try {
    const { title, description, fileUrl, recordType } = req.body;
    const patientId = req.user?.id;

    const medicalRecord = new MedicalRecordModel({
      patientId,
      title,
      description,
      fileUrl,
      recordType,
      status: 'pending',
    });

    await medicalRecord.save();

    // Send notification to all doctors in the hospital
    const { data: doctors } = await supabaseAdmin
      .from('doctors')
      .select('id');

    if (doctors && doctors.length > 0) {
      const notifications = doctors.map((doctor: any) => ({
        recipientId: doctor.id,
        senderId: patientId,
        type: 'record_uploaded',
        title: 'New Medical Record Uploaded',
        message: `Patient ${patientId} has uploaded a new medical record: ${title}`,
        relatedId: medicalRecord._id?.toString(),
      }));

      await NotificationModel.insertMany(notifications);
    }

    res.status(201).json({
      message: 'Medical record uploaded',
      data: medicalRecord,
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get patient's medical records
router.get('/patient/:patientId', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { patientId } = req.params;

    // Check authorization
    if (req.user?.role === 'patient' && req.user?.id !== patientId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const records = await MedicalRecordModel.find({ patientId }).sort({ uploadedAt: -1 });

    res.json(records);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Verify medical record (Doctor only)
router.patch('/:recordId/verify', authenticate, authorize(['doctor']), async (req: AuthRequest, res: Response) => {
  try {
    const { recordId } = req.params;

    const record = await MedicalRecordModel.findByIdAndUpdate(
      recordId,
      {
        status: 'verified',
        verifiedAt: new Date(),
        verifiedBy: req.user?.id,
      },
      { new: true }
    );

    if (!record) {
      return res.status(404).json({ error: 'Record not found' });
    }

    // Send notification to patient
    const notification = new NotificationModel({
      recipientId: record.patientId,
      senderId: req.user?.id,
      type: 'record_verified',
      title: 'Medical Record Verified',
      message: `Your medical record "${record.title}" has been verified by your doctor.`,
      relatedId: record._id?.toString(),
    });

    await notification.save();

    res.json({
      message: 'Record verified',
      data: record,
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;