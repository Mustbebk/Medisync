import { Router, Response } from 'express';
import { supabase, supabaseAdmin } from '../config/supabase';
import jwt from 'jsonwebtoken';
import { AuthRequest, authenticate } from '../middleware/auth';

const router = Router();

// Sign up
router.post('/signup', async (req: AuthRequest, res: Response) => {
  try {
    const { email, password, role, firstName, lastName, specialization, departmentId } = req.body;

    // Create user in Supabase Auth
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });

    if (authError) {
      return res.status(400).json({ error: authError.message });
    }

    const userId = authData.user?.id;

    // Create user profile in Supabase PostgreSQL
    if (role === 'patient') {
      const { error: dbError } = await supabaseAdmin
        .from('patients')
        .insert([
          {
            id: userId,
            email,
            firstName,
            lastName,
            criticality: 'low',
          },
        ]);

      if (dbError) {
        return res.status(400).json({ error: dbError.message });
      }
    } else if (role === 'doctor') {
      const { error: dbError } = await supabaseAdmin
        .from('doctors')
        .insert([
          {
            id: userId,
            email,
            specialization,
            departmentId,
            role: 'doctor',
          },
        ]);

      if (dbError) {
        return res.status(400).json({ error: dbError.message });
      }
    }

    const token = jwt.sign(
      { id: userId, email, role },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'User created successfully',
      userId,
      token,
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Login
router.post('/login', async (req: AuthRequest, res: Response) => {
  try {
    const { email, password } = req.body;

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      return res.status(401).json({ error: error.message });
    }

    const user = data.user;

    // Get user role from Supabase
    let role = 'patient';
    const { data: doctorData } = await supabaseAdmin
      .from('doctors')
      .select('id')
      .eq('id', user?.id)
      .single();

    if (doctorData) {
      role = 'doctor';
    }

    const token = jwt.sign(
      { id: user?.id, email: user?.email, role },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Login successful',
      userId: user?.id,
      email: user?.email,
      role,
      token,
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Logout
router.post('/logout', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    await supabase.auth.signOut();
    res.json({ message: 'Logout successful' });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;