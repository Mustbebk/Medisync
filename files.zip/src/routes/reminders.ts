import { Router, Response } from 'express';
import { ReminderModel } from '../models/Reminder';
import { CheckupModel } from '../models/Checkup';
import { AuthRequest, authenticate, authorize } from '../middleware/auth';
import { supabaseAdmin } from '../config/supabase';

const router = Router();

// Create reminder for unassigned patient (Admin)
router.post('/unassigned', authenticate, authorize(['admin']), async (req: AuthRequest, res: Response) => {
  try {
    const { patientId, scheduledFor } = req.body;

    const reminder = new ReminderModel({
      patientId,
      type: 'unassigned',
      title: 'Doctor Assignment Reminder',
      message: `Reminder: Patient ${patientId} is still unassigned. Please assign a doctor.`,
      scheduledFor: new Date(scheduledFor),
    });

    await reminder.save();

    res.status(201).json({
      message: 'Reminder created',
      data: reminder,
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create checkup reminder (Doctor)
router.post('/checkup', authenticate, authorize(['doctor']), async (req: AuthRequest, res: Response) => {
  try {
    const { patientId, scheduledDate, notes } = req.body;
    const doctorId = req.user?.id;

    const checkup = new CheckupModel({
      patientId,
      doctorId,
      scheduledDate: new Date(scheduledDate),
      notes,
    });

    await checkup.save();

    const reminder = new ReminderModel({
      patientId,
      doctorId,
      type: 'checkup',
      title: 'Scheduled Checkup Reminder',
      message: `You have a scheduled checkup on ${scheduledDate}`,
      scheduledFor: new Date(scheduledDate),
    });

    await reminder.save();

    res.status(201).json({
      message: 'Checkup scheduled',
      data: { checkup, reminder },
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all reminders for a user
router.get('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const reminders = await ReminderModel.find({
      $or: [
        { patientId: req.user?.id },
        { doctorId: req.user?.id }
      ]
    }).sort({ scheduledFor: 1 });

    res.json(reminders);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;