import { Router, Response } from 'express';
import { VitalSignsModel } from '../models/VitalSigns';
import { AlertModel } from '../models/Alert';
import { AuthRequest, authenticate, authorize } from '../middleware/auth';
import { supabaseAdmin } from '../config/supabase';

const router = Router();

// Submit vital signs (every 30 minutes)
router.post('/', authenticate, authorize(['patient']), async (req: AuthRequest, res: Response) => {
  try {
    const { heartRate, bloodPressureSystolic, bloodPressureDiastolic, temperature, oxygenLevel, respiratoryRate } =
      req.body;
    const patientId = req.user?.id;

    // Validate vital signs
    const isAbnormal =
      heartRate < 60 || heartRate > 100 ||
      bloodPressureSystolic > 140 || bloodPressureDiastolic > 90 ||
      temperature < 36.5 || temperature > 37.5 ||
      oxygenLevel < 95 ||
      respiratoryRate < 12 || respiratoryRate > 20;

    const vitalSigns = new VitalSignsModel({
      patientId,
      heartRate,
      bloodPressureSystolic,
      bloodPressureDiastolic,
      temperature,
      oxygenLevel,
      respiratoryRate,
      isAbnormal,
    });

    await vitalSigns.save();

    // Get patient info
    const { data: patient } = await supabaseAdmin
      .from('patients')
      .select('assignedDoctorId, criticality')
      .eq('id', patientId)
      .single();

    if (!patient?.assignedDoctorId) {
      return res.status(201).json({
        message: 'Vital signs recorded',
        data: vitalSigns,
        warning: 'No doctor assigned yet',
      });
    }

    // Check if abnormal and create alert
    if (isAbnormal) {
      const alertType = patient.criticality === 'critical' ? 'emergency' : 'warning';

      const alert = new AlertModel({
        patientId,
        doctorId: patient.assignedDoctorId,
        type: alertType,
        message: `Abnormal vital signs detected for patient ${patientId}`,
        vitalSignsId: vitalSigns._id?.toString(),
      });

      await alert.save();

      // Emit real-time alert via Socket.io
      // This will be handled in the socket events
    }

    res.status(201).json({
      message: 'Vital signs recorded',
      data: vitalSigns,
      isAbnormal,
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get vital signs history for a patient (Doctor/Patient)
router.get('/patient/:patientId', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { patientId } = req.params;
    const { limit = '100' } = req.query;

    // Check authorization
    if (req.user?.role === 'patient' && req.user?.id !== patientId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const vitalSigns = await VitalSignsModel.find({ patientId })
      .limit(parseInt(limit as string))
      .sort({ timestamp: -1 });

    res.json(vitalSigns);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;