import { Router, Response } from 'express';
import { supabaseAdmin } from '../config/supabase';
import { AuthRequest, authenticate, authorize } from '../middleware/auth';

const router = Router();

// Get all patients (Doctor only)
router.get('/', authenticate, authorize(['doctor', 'admin']), async (req: AuthRequest, res: Response) => {
  try {
    const { data, error } = await supabaseAdmin
      .from('patients')
      .select('*')
      .eq('assignedDoctorId', req.user?.id);

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get patient by ID
router.get('/:patientId', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { patientId } = req.params;

    // Check authorization
    if (req.user?.role === 'patient' && req.user?.id !== patientId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const { data, error } = await supabaseAdmin
      .from('patients')
      .select('*')
      .eq('id', patientId)
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update patient criticality (Doctor only)
router.patch('/:patientId/criticality', authenticate, authorize(['doctor', 'admin']), async (req: AuthRequest, res: Response) => {
  try {
    const { patientId } = req.params;
    const { criticality } = req.body;

    const validCriticalities = ['low', 'medium', 'high', 'critical'];
    if (!validCriticalities.includes(criticality)) {
      return res.status(400).json({ error: 'Invalid criticality level' });
    }

    const { data, error } = await supabaseAdmin
      .from('patients')
      .update({ criticality })
      .eq('id', patientId)
      .select();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({
      message: 'Criticality updated',
      data: data[0],
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Assign doctor to patient (Admin only)
router.patch('/:patientId/assign-doctor', authenticate, authorize(['admin']), async (req: AuthRequest, res: Response) => {
  try {
    const { patientId } = req.params;
    const { doctorId } = req.body;

    const { data, error } = await supabaseAdmin
      .from('patients')
      .update({ assignedDoctorId: doctorId })
      .eq('id', patientId)
      .select();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({
      message: 'Doctor assigned',
      data: data[0],
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;