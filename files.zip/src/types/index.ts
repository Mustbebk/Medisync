// User types
export interface User {
  id: string;
  email: string;
  role: 'doctor' | 'patient' | 'admin';
  createdAt: Date;
  updatedAt: Date;
}

export interface Doctor extends User {
  specialization: string;
  departmentId: string;
  licenseNumber: string;
}

export interface Patient extends User {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  medicalHistory: string;
  allergies: string;
  bloodType: string;
  emergencyContact: string;
  assignedDoctorId?: string;
  criticality: 'low' | 'medium' | 'high' | 'critical';
}

// Medical Records
export interface MedicalRecord {
  _id?: string;
  patientId: string;
  doctorId?: string;
  title: string;
  description: string;
  fileUrl: string;
  recordType: 'diagnosis' | 'prescription' | 'lab_report' | 'imaging' | 'other';
  uploadedAt: Date;
  verifiedAt?: Date;
  verifiedBy?: string;
  status: 'pending' | 'verified' | 'rejected';
}

// Vital Signs
export interface VitalSigns {
  _id?: string;
  patientId: string;
  heartRate: number;
  bloodPressureSystolic: number;
  bloodPressureDiastolic: number;
  temperature: number;
  oxygenLevel: number;
  respiratoryRate: number;
  timestamp: Date;
  isAbnormal: boolean;
}

// Alerts
export interface Alert {
  _id?: string;
  patientId: string;
  doctorId: string;
  type: 'emergency' | 'warning' | 'info';
  message: string;
  vitalSignsId?: string;
  isResolved: boolean;
  createdAt: Date;
  resolvedAt?: Date;
}

// Notifications
export interface Notification {
  _id?: string;
  recipientId: string;
  senderId: string;
  type: 'record_uploaded' | 'record_verified' | 'alert' | 'reminder' | 'checkup' | 'assignment';
  title: string;
  message: string;
  relatedId?: string;
  isRead: boolean;
  createdAt: Date;
  readAt?: Date;
}

// Reminders
export interface Reminder {
  _id?: string;
  patientId: string;
  doctorId?: string;
  type: 'unassigned' | 'checkup';
  title: string;
  message: string;
  scheduledFor: Date;
  isSent: boolean;
  sentAt?: Date;
  createdAt: Date;
}

// Checkups
export interface Checkup {
  _id?: string;
  patientId: string;
  doctorId: string;
  scheduledDate: Date;
  notes?: string;
  completed: boolean;
  completedAt?: Date;
  createdAt: Date;
}

// Department
export interface Department {
  id: string;
  name: string;
  code: string;
  createdAt: Date;
}