import cron from 'node-cron';
import { ReminderModel } from '../models/Reminder';
import { NotificationModel } from '../models/Notification';
import nodemailer from 'nodemailer';
import { supabaseAdmin } from '../config/supabase';

const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD,
  },
});

export const initializeReminderService = () => {
  // Run every minute to check for pending reminders
  cron.schedule('* * * * *', async () => {
    try {
      const now = new Date();

      // Find reminders that should be sent
      const pendingReminders = await ReminderModel.find({
        isSent: false,
        scheduledFor: { $lte: now },
      });

      for (const reminder of pendingReminders) {
        // Create notification
        const notification = new NotificationModel({
          recipientId: reminder.patientId,
          senderId: reminder.doctorId || 'system',
          type: reminder.type === 'unassigned' ? 'reminder' : 'checkup',
          title: reminder.title,
          message: reminder.message,
          relatedId: reminder._id?.toString(),
        });

        await notification.save();

        // Get patient email
        const { data: patient } = await supabaseAdmin
          .from('patients')
          .select('email')
          .eq('id', reminder.patientId)
          .single();

        if (patient?.email) {
          // Send email
          try {
            await transporter.sendMail({
              from: process.env.EMAIL_USER,
              to: patient.email,
              subject: reminder.title,
              text: reminder.message,
            });
          } catch (emailError) {
            console.error('Email sending error:', emailError);
          }
        }

        // Mark reminder as sent
        await ReminderModel.findByIdAndUpdate(reminder._id, {
          isSent: true,
          sentAt: new Date(),
        });
      }
    } catch (error) {
      console.error('Reminder service error:', error);
    }
  });

  console.log('Reminder service initialized');
};