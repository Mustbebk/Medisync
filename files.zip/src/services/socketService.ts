import { Server, Socket } from 'socket.io';
import jwt from 'jsonwebtoken';
import { AlertModel } from '../models/Alert';
import { NotificationModel } from '../models/Notification';
import { supabaseAdmin } from '../config/supabase';

interface AuthSocket extends Socket {
  userId?: string;
  userRole?: string;
}

export const initializeSocket = (io: Server) => {
  // Middleware for authentication
  io.use(async (socket: AuthSocket, next) => {
    try {
      const token = socket.handshake.auth.token;

      if (!token) {
        return next(new Error('No token provided'));
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret') as any;
      socket.userId = decoded.id;
      socket.userRole = decoded.role;
      next();
    } catch (error) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket: AuthSocket) => {
    console.log(`User ${socket.userId} connected`);

    // Join a room for the user (for personal notifications)
    socket.join(`user:${socket.userId}`);

    // Join doctor room if user is a doctor
    if (socket.userRole === 'doctor') {
      socket.join(`doctors`);
    }

    // Real-time vital signs streaming
    socket.on('vital-signs-update', async (data) => {
      try {
        const { patientId, vitalSigns } = data;

        // Get patient info
        const { data: patient } = await supabaseAdmin
          .from('patients')
          .select('assignedDoctorId, criticality')
          .eq('id', patientId)
          .single();

        if (patient?.assignedDoctorId) {
          // Emit to doctor
          io.to(`user:${patient.assignedDoctorId}`).emit('vital-signs-received', {
            patientId,
            ...vitalSigns,
            timestamp: new Date(),
          });
        }
      } catch (error) {
        console.error('Error in vital-signs-update:', error);
      }
    });

    // Alert notification
    socket.on('alert-triggered', async (data) => {
      try {
        const { patientId, alertType, message } = data;

        // Get assigned doctor
        const { data: patient } = await supabaseAdmin
          .from('patients')
          .select('assignedDoctorId')
          .eq('id', patientId)
          .single();

        if (patient?.assignedDoctorId) {
          io.to(`user:${patient.assignedDoctorId}`).emit('alert', {
            patientId,
            type: alertType,
            message,
            timestamp: new Date(),
          });
        }
      } catch (error) {
        console.error('Error in alert-triggered:', error);
      }
    });

    // Notification received
    socket.on('notification-received', async (data) => {
      try {
        const { recipientId, notification } = data;

        io.to(`user:${recipientId}`).emit('new-notification', notification);
      } catch (error) {
        console.error('Error in notification-received:', error);
      }
    });

    // Department notification
    socket.on('department-notification', async (data) => {
      try {
        const { departmentId, notification } = data;

        // Get all doctors in the department
        const { data: doctors } = await supabaseAdmin
          .from('doctors')
          .select('id')
          .eq('departmentId', departmentId);

        if (doctors) {
          doctors.forEach((doctor: any) => {
            io.to(`user:${doctor.id}`).emit('department-alert', notification);
          });
        }
      } catch (error) {
        console.error('Error in department-notification:', error);
      }
    });

    socket.on('disconnect', () => {
      console.log(`User ${socket.userId} disconnected`);
    });
  });
};