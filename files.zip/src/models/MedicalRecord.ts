import mongoose, { Schema, Document } from 'mongoose';

interface IMedicalRecord extends Document {
  patientId: string;
  doctorId?: string;
  title: string;
  description: string;
  fileUrl: string;
  recordType: 'diagnosis' | 'prescription' | 'lab_report' | 'imaging' | 'other';
  uploadedAt: Date;
  verifiedAt?: Date;
  verifiedBy?: string;
  status: 'pending' | 'verified' | 'rejected';
}

const medicalRecordSchema = new Schema<IMedicalRecord>({
  patientId: { type: String, required: true, index: true },
  doctorId: { type: String, sparse: true },
  title: { type: String, required: true },
  description: { type: String, required: true },
  fileUrl: { type: String, required: true },
  recordType: {
    type: String,
    enum: ['diagnosis', 'prescription', 'lab_report', 'imaging', 'other'],
    required: true,
  },
  uploadedAt: { type: Date, default: Date.now },
  verifiedAt: { type: Date, sparse: true },
  verifiedBy: { type: String, sparse: true },
  status: { type: String, enum: ['pending', 'verified', 'rejected'], default: 'pending' },
});

export const MedicalRecordModel = mongoose.model<IMedicalRecord>(
  'MedicalRecord',
  medicalRecordSchema
);