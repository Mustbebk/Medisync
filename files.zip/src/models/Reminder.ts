import mongoose, { Schema, Document } from 'mongoose';

interface IReminder extends Document {
  patientId: string;
  doctorId?: string;
  type: 'unassigned' | 'checkup';
  title: string;
  message: string;
  scheduledFor: Date;
  isSent: boolean;
  sentAt?: Date;
  createdAt: Date;
}

const reminderSchema = new Schema<IReminder>({
  patientId: { type: String, required: true, index: true },
  doctorId: { type: String, sparse: true },
  type: { type: String, enum: ['unassigned', 'checkup'], required: true },
  title: { type: String, required: true },
  message: { type: String, required: true },
  scheduledFor: { type: Date, required: true, index: true },
  isSent: { type: Boolean, default: false },
  sentAt: { type: Date, sparse: true },
  createdAt: { type: Date, default: Date.now },
});

export const ReminderModel = mongoose.model<IReminder>('Reminder', reminderSchema);