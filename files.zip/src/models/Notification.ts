import mongoose, { Schema, Document } from 'mongoose';

interface INotification extends Document {
  recipientId: string;
  senderId: string;
  type: 'record_uploaded' | 'record_verified' | 'alert' | 'reminder' | 'checkup' | 'assignment';
  title: string;
  message: string;
  relatedId?: string;
  isRead: boolean;
  createdAt: Date;
  readAt?: Date;
}

const notificationSchema = new Schema<INotification>({
  recipientId: { type: String, required: true, index: true },
  senderId: { type: String, required: true },
  type: {
    type: String,
    enum: ['record_uploaded', 'record_verified', 'alert', 'reminder', 'checkup', 'assignment'],
    required: true,
  },
  title: { type: String, required: true },
  message: { type: String, required: true },
  relatedId: { type: String, sparse: true },
  isRead: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now, index: true },
  readAt: { type: Date, sparse: true },
});

export const NotificationModel = mongoose.model<INotification>(
  'Notification',
  notificationSchema
);