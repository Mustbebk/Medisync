import mongoose, { Schema, Document } from 'mongoose';

interface IVitalSigns extends Document {
  patientId: string;
  heartRate: number;
  bloodPressureSystolic: number;
  bloodPressureDiastolic: number;
  temperature: number;
  oxygenLevel: number;
  respiratoryRate: number;
  timestamp: Date;
  isAbnormal: boolean;
}

const vitalSignsSchema = new Schema<IVitalSigns>({
  patientId: { type: String, required: true, index: true },
  heartRate: { type: Number, required: true },
  bloodPressureSystolic: { type: Number, required: true },
  bloodPressureDiastolic: { type: Number, required: true },
  temperature: { type: Number, required: true },
  oxygenLevel: { type: Number, required: true },
  respiratoryRate: { type: Number, required: true },
  timestamp: { type: Date, default: Date.now, index: true },
  isAbnormal: { type: Boolean, default: false },
});

export const VitalSignsModel = mongoose.model<IVitalSigns>(
  'VitalSigns',
  vitalSignsSchema
);