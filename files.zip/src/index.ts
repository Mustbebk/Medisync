import express, { Express } from 'express';
import cors from 'cors';
import morgan from 'morgan';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import dotenv from 'dotenv';

import { connectMongoDB } from './config/mongodb';
import { initializeSocket } from './services/socketService';
import { initializeReminderService } from './services/reminderService';

import authRoutes from './routes/auth';
import patientRoutes from './routes/patients';
import medicalRecordsRoutes from './routes/medicalRecords';
import vitalSignsRoutes from './routes/vitalSigns';
import reminderRoutes from './routes/reminders';

dotenv.config();

const app: Express = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, {
  cors: {
    origin: process.env.CLIENT_URL || 'http://localhost:3000',
    methods: ['GET', 'POST'],
  },
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(morgan('combined'));

// Connect to MongoDB
connectMongoDB();

// Initialize services
initializeSocket(io);
initializeReminderService();

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/patients', patientRoutes);
app.use('/api/medical-records', medicalRecordsRoutes);
app.use('/api/vital-signs', vitalSignsRoutes);
app.use('/api/reminders', reminderRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'Server is running' });
});

const PORT = process.env.PORT || 5000;

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export { io };