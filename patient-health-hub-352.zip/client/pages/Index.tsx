import Layout from "@/components/Layout";
import { Link } from "react-router-dom";
import {
  Users,
  FileText,
  Bell,
  Lock,
  Share2,
  Zap,
  ClipboardList,
  Heart,
  MessageSquare,
} from "lucide-react";

export default function Index() {
  return (
    <Layout showNav={true}>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-beige via-white to-white pt-20 pb-32 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-6xl font-bold text-primary mb-6">
              Unified Patient Care,
              <span className="block text-accent"> Simplified.</span>
            </h1>
            <p className="text-xl text-foreground/80 max-w-2xl mx-auto mb-8">
              MediCare connects patients, doctors, and departments in a seamless
              platform for real-time collaboration, comprehensive health records,
              and coordinated care.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/patient-signup"
                className="px-8 py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:opacity-90 transition-opacity"
              >
                Patient Login
              </Link>
              <Link
                to="/provider-signup"
                className="px-8 py-3 border-2 border-primary text-primary font-semibold rounded-lg hover:bg-primary/5 transition-colors"
              >
                Provider Portal
              </Link>
            </div>
          </div>

          {/* Hero Image Placeholder */}
          <div className="bg-gradient-to-b from-accent/30 to-dusty-blue/20 rounded-2xl h-96 flex items-center justify-center border border-accent/30">
            <div className="text-center">
              <Heart className="w-20 h-20 text-accent mx-auto mb-4 opacity-60" />
              <p className="text-foreground/60 font-medium">
                Integrated Healthcare Management System
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-primary mb-4">
            Comprehensive Healthcare Features
          </h2>
          <p className="text-center text-foreground/70 mb-16 max-w-2xl mx-auto">
            Everything you need for modern patient care management in one
            platform
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="p-6 border border-border rounded-xl hover:border-accent transition-colors bg-beige/50">
              <FileText className="w-10 h-10 text-primary mb-4" />
              <h3 className="text-lg font-semibold text-primary mb-2">
                Complete Patient Records
              </h3>
              <p className="text-foreground/70">
                All patient information, lab results, medications, and medical
                history accessible in one place.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="p-6 border border-border rounded-xl hover:border-accent transition-colors bg-beige/50">
              <Share2 className="w-10 h-10 text-primary mb-4" />
              <h3 className="text-lg font-semibold text-primary mb-2">
                Real-Time Collaboration
              </h3>
              <p className="text-foreground/70">
                Seamless information sharing across departments without manual
                interruptions or delays.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="p-6 border border-border rounded-xl hover:border-accent transition-colors bg-beige/50">
              <Bell className="w-10 h-10 text-primary mb-4" />
              <h3 className="text-lg font-semibold text-primary mb-2">
                Smart Notifications
              </h3>
              <p className="text-foreground/70">
                Appointment reminders, status updates, and alerts via email and
                in-app notifications.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="p-6 border border-border rounded-xl hover:border-accent transition-colors bg-beige/50">
              <Lock className="w-10 h-10 text-primary mb-4" />
              <h3 className="text-lg font-semibold text-primary mb-2">
                Role-Based Security
              </h3>
              <p className="text-foreground/70">
                Advanced access control ensures each user only sees what they
                need for their role.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="p-6 border border-border rounded-xl hover:border-accent transition-colors bg-beige/50">
              <ClipboardList className="w-10 h-10 text-primary mb-4" />
              <h3 className="text-lg font-semibold text-primary mb-2">
                Department Requests
              </h3>
              <p className="text-foreground/70">
                Doctors request tests and services; departments respond with
                results in real time.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="p-6 border border-border rounded-xl hover:border-accent transition-colors bg-beige/50">
              <Zap className="w-10 h-10 text-primary mb-4" />
              <h3 className="text-lg font-semibold text-primary mb-2">
                Instant Updates
              </h3>
              <p className="text-foreground/70">
                Patients receive live updates about their health status, test
                results, and upcoming appointments.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* User Types Section */}
      <section className="py-20 px-4 bg-beige">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-primary mb-16">
            Built for Everyone
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Patients */}
            <div className="bg-white rounded-xl p-8 border-l-4 border-accent">
              <Users className="w-12 h-12 text-accent mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-3">Patients</h3>
              <ul className="space-y-2 text-foreground/70 mb-6">
                <li className="flex items-start gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span>View your complete health records</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span>Track lab results in real time</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span>Receive appointment reminders</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span>Stay updated on your status</span>
                </li>
              </ul>
              <Link
                to="/patient-signup"
                className="inline-block px-6 py-2 bg-accent text-accent-foreground font-semibold rounded-lg hover:opacity-90 transition-opacity"
              >
                Access Dashboard
              </Link>
            </div>

            {/* Doctors */}
            <div className="bg-white rounded-xl p-8 border-l-4 border-dusty-blue">
              <Heart className="w-12 h-12 text-dusty-blue mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-3">
                Doctors & Providers
              </h3>
              <ul className="space-y-2 text-foreground/70 mb-6">
                <li className="flex items-start gap-2">
                  <span className="text-dusty-blue font-bold">•</span>
                  <span>Access complete patient histories</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-dusty-blue font-bold">•</span>
                  <span>Request tests from departments</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-dusty-blue font-bold">•</span>
                  <span>Collaborate with specialists</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-dusty-blue font-bold">•</span>
                  <span>Manage multiple patients</span>
                </li>
              </ul>
              <Link
                to="/provider-signup"
                className="inline-block px-6 py-2 bg-dusty-blue text-white font-semibold rounded-lg hover:opacity-90 transition-opacity"
              >
                Provider Portal
              </Link>
            </div>

            {/* Departments */}
            <div className="bg-white rounded-xl p-8 border-l-4 border-primary">
              <MessageSquare className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-3">
                Lab & Departments
              </h3>
              <ul className="space-y-2 text-foreground/70 mb-6">
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>Receive test requests instantly</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>Upload results in real time</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>Manage your workload</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>Coordinate with other departments</span>
                </li>
              </ul>
              <Link
                to="/department-signup"
                className="inline-block px-6 py-2 bg-primary text-primary-foreground font-semibold rounded-lg hover:opacity-90 transition-opacity"
              >
                Department Access
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary to-primary/90">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-primary-foreground mb-6">
            Ready to Transform Your Healthcare?
          </h2>
          <p className="text-lg text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            Join hospitals and clinics that have streamlined their patient care
            with MediCare. Secure, simple, and built for modern medicine.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/patient-signup"
              className="px-8 py-3 bg-accent text-accent-foreground font-semibold rounded-lg hover:opacity-90 transition-opacity"
            >
              Start as Patient
            </Link>
            <Link
              to="/provider-signup"
              className="px-8 py-3 bg-white text-primary font-semibold rounded-lg hover:bg-primary-foreground transition-colors"
            >
              Provider Sign Up
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-border px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-sm">
                    +
                  </span>
                </div>
                <span className="font-bold text-primary">MediCare</span>
              </div>
              <p className="text-sm text-foreground/70">
                Unified patient care management system
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-primary mb-3">Product</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Features
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Security
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-primary mb-3">Company</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    About
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-primary mb-3">Legal</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Privacy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Terms
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-foreground/60">
            <p>&copy; 2024 MediCare. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </Layout>
  );
}
