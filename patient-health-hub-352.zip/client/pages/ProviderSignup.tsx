import Placeholder from "./Placeholder";

export default function ProviderSignup() {
  return (
    <Placeholder
      title="Provider Portal"
      description="Access complete patient records, request lab tests from departments, collaborate with specialists, and manage your patient caseload. Doctor authentication setup coming soon."
    />
  );
}
