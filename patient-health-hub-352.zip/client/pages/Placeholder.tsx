import Layout from "@/components/Layout";
import { Link } from "react-router-dom";

interface PlaceholderProps {
  title: string;
  description: string;
}

export default function Placeholder({ title, description }: PlaceholderProps) {
  return (
    <Layout>
      <div className="min-h-[calc(100vh-80px)] flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <div className="w-8 h-8 bg-accent rounded-full"></div>
          </div>
          <h1 className="text-3xl font-bold text-primary mb-3">{title}</h1>
          <p className="text-foreground/70 mb-8">{description}</p>
          <Link
            to="/"
            className="inline-block px-6 py-2 bg-primary text-primary-foreground font-semibold rounded-lg hover:opacity-90 transition-opacity"
          >
            Back to Home
          </Link>
        </div>
      </div>
    </Layout>
  );
}
