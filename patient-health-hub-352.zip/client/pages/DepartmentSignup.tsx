import Placeholder from "./Placeholder";

export default function DepartmentSignup() {
  return (
    <Placeholder
      title="Department Portal"
      description="Manage test requests from doctors, upload results in real time, track your workload, and coordinate with other departments. Department access setup coming soon."
    />
  );
}
