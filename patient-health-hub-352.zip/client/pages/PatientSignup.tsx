import Placeholder from "./Placeholder";

export default function PatientSignup() {
  return (
    <Placeholder
      title="Patient Portal"
      description="Access your health records, lab results, medications, and appointment reminders. Complete signup and authentication setup coming soon."
    />
  );
}
